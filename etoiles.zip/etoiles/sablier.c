#include <stdio.h>

int main(int argc, char const *argv[])
{
    /* Sablier */
    int n ;// la taille du sablier
    int i, j , k=1 ;
     
       
        /* controle de saisie*/
        printf("Donner la taille du sablier :");
        scanf("%d",&n);
        do
       {
        if(n<=0 || n%2 == 0)
        {
           printf("ATTENTION !!! y'a une ou des erreurs \n");
           printf("la taille du sablier doit etre strictement positive et impaire\n");
           printf("Donner la taille du sablier :");
           scanf("%d",&n); 
        }
       } while (n<0 || n%2 == 0)  ;
       for ( i = 1; i <= n; i++)
       {
            for (j =1; j <= n; j++)
            {
                if (j>=k && j<=n-k +1)
                {
                   printf("\033[31m" );
                   printf("*");
                }
    
                else
                printf(" ");
            }
            if(i<=n/2)
             {
               k++; 
             }
                
            else
              k--;
            printf("\n");
       }
    return 0;
}
