#include <stdio.h>

int main(int argc, char const *argv[])
{
    /* Sablier */
    int n ;// la taille du sablier
    int i, j , k=1 ;
     
       
        /* controle de saisie*/
        printf("Donner la taille du sablier :");
        scanf("%d",&n);
        do
       {
        if(n<=0)
        {
           printf("ATTENTION !!! y'a une ou des erreurs \n");
           printf("la taille du sablier doit etre strictement positive\n");
           printf("Donner la taille du sablier :");
           scanf("%d",&n); 
        }
       } while (n<0);
       for (i = 0; i <= n ; i++)
       {
          for ( j = 0; j <= n; j++)
           {
                if (i % 2 == 0)//paire
                {
                    if (j % 2 != 0)
                    {
                        printf("\033[32m" );
                        printf(" o ");
                    }  
                    else
                    {
                       printf("\033[31m" );
                       printf(" o ");
                    }
                        
                }
                else
                {
                    if (j % 2 != 0)//impaire
                       {
                       printf("\033[31m" );
                       printf(" o ");
                    }
                    else
                        {
                        printf("\033[32m" );
                        printf(" o ");
                       } 
               }
            } 
            printf("\n");
        }

    return 0;
}